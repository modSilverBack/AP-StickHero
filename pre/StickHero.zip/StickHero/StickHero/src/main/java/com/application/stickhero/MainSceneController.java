package com.application.stickhero;

import javafx.animation.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.io.IOException;
import java.util.Objects;

public class MainSceneController {
    @FXML
    private AnchorPane rootPane;
    @FXML
    private CheckBox musicCheckbox;
    @FXML
    private Button playButton;
    @FXML
    private Button avatarsButton;
    @FXML
    private Label berriesCount;
    MediaPlayer mediaPlayer;
    private Scene mainScene;
    @FXML
    private void initialize() {
        String musicFilePath = App.class.getResource("music.mp3").toString();
        Media media = new Media(musicFilePath);
        mediaPlayer = new MediaPlayer(media);
        mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);

        TranslateTransition translateTransition = new TranslateTransition(Duration.seconds(1), playButton);
        translateTransition.setByY(-3);
        translateTransition.setAutoReverse(true);
        translateTransition.setCycleCount(TranslateTransition.INDEFINITE);

        ScaleTransition scaleTransition = new ScaleTransition(Duration.seconds(1), playButton);
        scaleTransition.setToX(1.02);
        scaleTransition.setToY(1.02);
        scaleTransition.setAutoReverse(true);
        scaleTransition.setCycleCount(ScaleTransition.INDEFINITE);

        ParallelTransition parallelTransition = new ParallelTransition(translateTransition, scaleTransition);
        parallelTransition.play();
    }

    @FXML
    private void toggleMusic() {
        if (musicCheckbox.isSelected()) {
            mediaPlayer.play();
        } else {
            mediaPlayer.pause();
        }
    }

    @FXML
    private void switchToPlayScene() throws IOException {
        Stage stage = (Stage) musicCheckbox.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource("GameScene.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        mainScene = scene;
        stage.setScene(scene);
    }

    @FXML
    private void switchToHelpScene() throws IOException {
        FXMLLoader helpLoader = new FXMLLoader(App.class.getResource("HelpScene.fxml"));
        Scene helpScene = new Scene(helpLoader.load());

        HelpSceneController helpSceneController = helpLoader.getController();
        helpSceneController.initialize();

        Stage stage = (Stage) rootPane.getScene().getWindow();
        stage.setScene(helpScene);
    }

    @FXML
    private void switchToShopScene() throws IOException {
        System.out.println("Switching to Shop Scene");
        Stage stage = (Stage) musicCheckbox.getScene().getWindow();
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource("Shop.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        mainScene = scene;
        stage.setScene(scene);
    }

    @FXML
    private void switchToAvatarSelectionScene() throws IOException {
        FXMLLoader avatarLoader = new FXMLLoader(App.class.getResource("AvatarSelection.fxml"));
        Scene avatarScene = new Scene(avatarLoader.load());

        AvatarSelectionController avatarController = avatarLoader.getController();

        avatarController.setMainSceneController(this);

        Stage stage = (Stage) rootPane.getScene().getWindow();
        stage.setScene(avatarScene);
    }

    public Scene getMainScene() {
        return mainScene;
    }


    @FXML
    private ImageView avatarImageView;

    @FXML
    public void applyAvatar(String avatarImageName) {
        // Change the avatar image in the main screen
        String imagePath = "/com/application/stickhero/" + avatarImageName;
        Image avatarImage = new Image(Objects.requireNonNull(getClass().getResource(imagePath)).toExternalForm());
        avatarImageView.setImage(avatarImage);
    }


    private AvatarSelectionController avatarSelectionController;
    private HelpSceneController helpSceneController;
    private Shop shopSceneController;
    public void setAvatarSelectionController(AvatarSelectionController avatarSelectionController) {
        this.avatarSelectionController = avatarSelectionController;
    }
    public void setHelpSceneController(HelpSceneController helpSceneController) {
        this.helpSceneController = helpSceneController;
    }
    public void setShopSceneController(Shop shopSceneController) {
        this.shopSceneController = shopSceneController;
    }
    @FXML
    private ImageView adImageView;
    @FXML
    private CheckBox noAdsCheckbox;
    @FXML
    private void toggleNoAds() {
        if (noAdsCheckbox.isSelected()) {
            mediaPlayer.stop();
            adImageView.setVisible(false);
            System.out.println("Ads disabled");
        } else {
            mediaPlayer.play();
            adImageView.setVisible(true);
            System.out.println("Ads enabled");
        }
    }
}
