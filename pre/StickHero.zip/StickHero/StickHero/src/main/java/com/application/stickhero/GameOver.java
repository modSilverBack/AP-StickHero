package com.application.stickhero;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
public class GameOver {
    @FXML
    private Label berriesLabel;
    @FXML
    private Label highScoreLabel;
    @FXML
    private AnchorPane rootPane;

    public void initialize(int berriesCount, int highScore) {
        berriesLabel.setText("Berries: " + berriesCount);
        highScoreLabel.setText("High Score: " + highScore);
    }
    @FXML
    private void returnToHome() throws IOException {
        Stage stage = (Stage) rootPane.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(App.class.getResource("MainScene.fxml"));
        Scene scene = new Scene(loader.load());
        stage.setScene(scene);
    }

    @FXML
    private void replay() throws IOException {
     Stage stage = (Stage) rootPane.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(App.class.getResource("GameScene.fxml"));
        Scene scene = new Scene(loader.load());
        stage.setScene(scene);

        PlayGameController playGameController = loader.getController();
        playGameController.initialize();
    }
    @FXML
    private void viewStats() throws IOException {
        // separate FXML n controller for stats screen
        Stage stage = (Stage) rootPane.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(App.class.getResource("StatsScreen.fxml"));
        Scene scene = new Scene(loader.load());
        stage.setScene(scene);
    }
}
