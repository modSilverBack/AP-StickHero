package com.application.stickhero;
//
//import javafx.animation.*;
//import javafx.fxml.FXML;
//import javafx.scene.image.ImageView;
//import javafx.scene.input.KeyCode;
//import javafx.scene.layout.AnchorPane;
//import javafx.scene.paint.Color;
//import javafx.scene.shape.Rectangle;
//import javafx.util.Duration;
//
//import java.util.Random;
//
//public class PlayGameController {
//
//    @FXML
//    private AnchorPane rootPane;
//    @FXML
//    private ImageView stickImageView;
//
//    private boolean isStickExtended = false;
//    private boolean isRevived = false;
//
//    private double stickHeight = 113.0;
//    private double characterSpeed = 5.0;
//    private double pillarGap = 200.0;
//    private double platformWidth;
//
//    private int score = 0;
//    private int cherriesCollected = 0;
//    private int cherriesForRevive = 3;
//
//    private Random random = new Random();
//
//    private Rectangle platform;
//    private TranslateTransition fallTransition;
//
//    @FXML
//    private void initialize() {
//        setupKeyHandlers();
//        generatePlatform();
//        extendStick();
//        setupFallAnimation();
//    }
//
//    private void setupKeyHandlers() {
//        rootPane.setOnKeyPressed(event -> {
//            if (event.getCode() == KeyCode.SPACE) {
//                onRelease();
//            } else if (event.getCode() == KeyCode.UP) {
//                flipCharacter();
//            }
//        });
//    }
//
//    @FXML
//    private void onRelease() {
//        if (isStickExtended) {
//            fallStick();
//        }
//    }
//
//    private void extendStick() {
//        isStickExtended = true;
//
//        Rectangle stick = new Rectangle(0, 0, 10, stickHeight);
//        stick.setTranslateX(stickImageView.getTranslateX() + stickImageView.getFitWidth());
//        stick.setTranslateY(stickImageView.getTranslateY() + stickImageView.getFitHeight() / 2);
//
//        TranslateTransition extendTransition = new TranslateTransition(Duration.seconds(2), stick);
//        extendTransition.setToX(platform.getTranslateX() + platform.getWidth());
//        extendTransition.play();
//
//        extendTransition.setOnFinished(event -> {
//            rootPane.getChildren().add(stick);
//            isStickExtended = false;
//            checkPlatformOverlap(stick);
//        });
//    }
//
//    private void fallStick() {
//        double stickHeight = stickImageView.getFitHeight();
//        double sceneHeight = rootPane.getHeight();
//
//        fallTransition = new TranslateTransition(Duration.seconds(2), stickImageView);
//        fallTransition.setToY(sceneHeight - stickHeight);
//        fallTransition.play();
//
//        fallTransition.setOnFinished(event -> {
//            if (!isRevived) {
//                gameOver();
//            }
//        });
//    }
//
//    private void checkPlatformOverlap(Rectangle stick) {
//        if (stick.getBoundsInParent().intersects(platform.getBoundsInParent())) {
//            // Stick landed on the platform
//            score++;
//            cherriesCollected++;
//
//            if (cherriesCollected >= cherriesForRevive) {
//                cherriesCollected = 0;
//                isRevived = true;
//            }
//
//            rootPane.getChildren().remove(stick);
//            generatePlatform();
//            updateScore();
//        } else {
//            // Stick missed the platform
//            fallStick();
//        }
//    }
//
//    private void generatePlatform() {
//        double newPlatformWidth = random.nextDouble() * 150 + 50;
//        double platformX = platform == null ? 0 : platform.getTranslateX() + pillarGap;
//        double platformY = rootPane.getHeight() - 20;
//
//        platform = new Rectangle(newPlatformWidth, 20);
//        platform.setTranslateX(platformX);
//        platform.setTranslateY(platformY);
//        platform.setFill(Color.GREEN);
//
//        rootPane.getChildren().add(platform);
//        platformWidth = newPlatformWidth;
//    }
//
//    private void updateScore() {
//        System.out.println("Score: " + score);
//    }
//
//    private void flipCharacter() {
//        // Logic to flip the character upside down (e.g., rotate the ImageView)
//        // You can use a RotateTransition for a smoother effect
//        stickImageView.setScaleY(stickImageView.getScaleY() * -1);
//    }
//
//    private void gameOver() {
//        PauseTransition pauseTransition = new PauseTransition(Duration.seconds(2));
//        pauseTransition.setOnFinished(e -> resetGame());
//        pauseTransition.play();
//    }
////    @FXML
////    private void switchToGameOverScene() throws IOException {
////        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource("GameOverScene.fxml"));
////        Scene gameOverScene = new Scene(fxmlLoader.load());
////
////        // Set up the GameOverController if needed
////        GameOverController gameOverController = fxmlLoader.getController();
////        gameOverController.setScore(score); // Pass relevant data to the GameOverController
////
////        Stage stage = (Stage) rootPane.getScene().getWindow();
////        stage.setScene(gameOverScene);
////    }
//    private void resetGame() {
//        rootPane.getChildren().clear();
//        score = 0;
//        cherriesCollected = 0;
//        isRevived = false;
//        generatePlatform();
//        extendStick();
//    }
//
//    private void setupFallAnimation() {
//        // Add any additional setup for the fall animation if needed
//    }
//}
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

import java.util.Objects;
import java.util.Random;

public class PlayGameController {
    // In PlayGameController
    private GameProgressManager gameProgressManager;
    public void setGameProgressManager(GameProgressManager gameProgressManager) {
        this.gameProgressManager = gameProgressManager;
    }


    @FXML
    private void saveProgress() {
        // Save the player's progress using gameProgressManager
        gameProgressManager.setLastScore(score);
        // Implement other saving logic here
        PlayGameController playGameController = new PlayGameController();
        playGameController.setGameProgressManager(new GameProgressManager());


    }

    @FXML
    private Label berriesCountLabel;
    @FXML
    private AnchorPane rootPane;

    private Rectangle stick;
    private double stickHeight = 0.0;
    private boolean isFalling = false;

    private Rectangle platform;
    private double platformGap = 200.0;

    private Random random = new Random();
    @FXML
    private Label scoreLabel;

    private int score = 0;

    @FXML
    void initialize() {
        if (rootPane == null) {
            System.err.println("rootPane is null!");
            return;
        }
        rootPane.requestFocus();
        setupKeyHandlers();
        generatePlatform();
        scoreLabel.setText("Score: " + score);
    }


    void setupKeyHandlers() {
        rootPane.setOnKeyPressed(this::handleKeyPress);
        rootPane.setOnKeyReleased(this::handleKeyReleased);
    }

    @FXML
    private void handleKeyPress(KeyEvent event) {
        System.out.println("Key Pressed: " + event.getCode());
        if (event.getCode() == KeyCode.SPACE) {
            extendStick();
        }
    }

    @FXML
    private void handleKeyReleased(KeyEvent event) {
        System.out.println("Key Released: " + event.getCode());
        if (event.getCode() == KeyCode.SPACE) {
            fallStick();
        }
    }

    private void extendStick() {
        stick = new Rectangle(5, 0); // Initial stick size
        stick.setLayoutX(platform.getLayoutX() + platform.getWidth() / 2);
        stick.setLayoutY(platform.getLayoutY());

        rootPane.getChildren().add(stick);

        TranslateTransition extendTransition = new TranslateTransition(Duration.seconds(2), stick);
        extendTransition.setByY(-platformGap); // Extend the stick vertically
        extendTransition.play();

        extendTransition.setOnFinished(event -> {
            stickHeight = stick.getHeight();
            isFalling = true;
        });
    }

    private void fallStick() {
        if (isFalling) {
            TranslateTransition fallTransition = new TranslateTransition(Duration.seconds(2), stick);
            fallTransition.setByX(platformGap); // Fall the stick horizontally
            fallTransition.play();

            fallTransition.setOnFinished(event -> {
                checkPlatformOverlap();
            });
        }
    }

    private void checkPlatformOverlap() {
        if (stickHeight >= platform.getWidth() || stickHeight <= platform.getWidth() / 2) {
            // Stick landed successfully on the next platform
            score++; // Increase the score
            scoreLabel.setText("Score: " + score); // Update the score label
            generatePlatform(); // Move to the next platform
            isFalling = false;
            rootPane.getChildren().remove(stick); // Remove the stick
        } else {
            // Stick missed the platform
            // Handle game-over logic here
            System.out.println("Game Over");
        }
    }

    private void generatePlatform() {
        double newPlatformWidth = random.nextDouble() * 150 + 50;
        double platformX = random.nextDouble() * (rootPane.getWidth() - newPlatformWidth);
        double platformY = rootPane.getHeight() - 20;

        platform = new Rectangle(newPlatformWidth, 20);
        platform.setLayoutX(platformX);
        platform.setLayoutY(platformY);

        rootPane.getChildren().add(platform);
    }

    @FXML
    private ImageView heroImageView;

    // Add an ImageView for the avatar in the game scene
    @FXML
    private ImageView avatarImageView;
    public void updateAvatar(String avatarImageName) {
        String imagePath = "/com/application/stickhero/" + avatarImageName;
        Image avatarImage = new Image(Objects.requireNonNull(getClass().getResource(imagePath)).toExternalForm());
        avatarImageView.setImage(avatarImage);
    }

}
