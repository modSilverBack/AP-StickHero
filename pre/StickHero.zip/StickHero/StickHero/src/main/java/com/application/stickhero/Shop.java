package com.application.stickhero;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class Shop {
    private MainSceneController mainSceneController;

    public void setMainSceneController(MainSceneController mainSceneController) {
        this.mainSceneController = mainSceneController;
    }
    @FXML
    private AnchorPane rootPane;
    @FXML
    private void switchToMainScene() throws IOException {
        // Load the main scene FXML
        FXMLLoader mainLoader = new FXMLLoader(App.class.getResource("MainScene.fxml"));
        Scene mainScene = new Scene(mainLoader.load());

        // Set up the MainSceneController
        MainSceneController mainController = mainLoader.getController();

        // Pass a reference to the HelpSceneController to the MainSceneController
        mainController.setShopSceneController(this);

        // Switch to the main scene
        Stage stage = (Stage) rootPane.getScene().getWindow();
        stage.setScene(mainScene);
    }

    @FXML
    private void purchaseBerries() {
        // Implement your logic for purchasing berries
        // For now, show a simple alert
        showAlert("Berries Purchased", "You've successfully purchased berries!");
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
