package com.application.stickhero;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.Objects;

public class App extends Application {
    private GameProgressManager progressManager = new GameProgressManager();

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader mainLoader = new FXMLLoader(App.class.getResource("MainScene.fxml"));
        Scene mainScene = new Scene(mainLoader.load());

        FXMLLoader playLoader = new FXMLLoader(App.class.getResource("GameScene.fxml"));
        playLoader.load();

        PlayGameController playGameController = playLoader.getController();
        playGameController.initialize();
        playGameController.setGameProgressManager(progressManager);

        stage.setTitle("StickHero");

        Image icon = new Image(Objects.requireNonNull(getClass().getResourceAsStream("hero.png")));
        stage.getIcons().add(icon);
        stage.setResizable(false);
        stage.setScene(mainScene);
        stage.show();
    }
    public static void main(String[] args) {
        launch();
    }
}
