package com.application.stickhero;
// Singleton Design Pattern
public class GameProgressManager {
    private static GameProgressManager instance;
    private GameProgressManager() {
    }
    public static GameProgressManager getInstance() {
        if (instance == null) {
            instance = new GameProgressManager();
        }
        return instance;
    }

    private int lastScore;
    private int highestScore;
    private int totalCherries;

    public void setLastScore(int score) {
        this.lastScore=score;
    }


}
