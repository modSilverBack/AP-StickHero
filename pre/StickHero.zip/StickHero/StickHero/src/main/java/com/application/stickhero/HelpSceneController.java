package com.application.stickhero;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.scene.control.Label;
import java.io.IOException;

public class HelpSceneController {

    @FXML
    private AnchorPane rootPane;
    //    @FXML
//    private Rectangle platform1;
//    @FXML
//    private Rectangle platform2;
    @FXML
    private Label instructionLabel;
    @FXML
    private ImageView stickHeroPlayer;
    @FXML
    private Rectangle stickRectangle;  // Add this line

    private Timeline extendStickTimeline;
    private boolean isStickExtended;
    @FXML
    void initialize() {
        isStickExtended = false;

        // Initialize the Timeline for stick extension
        extendStickTimeline = new Timeline();
        extendStickTimeline.getKeyFrames().add(
                new KeyFrame(Duration.seconds(1), new KeyValue(stickRectangle.heightProperty(), 300))
        );
        extendStickTimeline.setOnFinished(event -> {
            // Stick extension animation is complete
            isStickExtended = true;
        });

        // Add a key pressed event filter to consume the UP key press event
        stickRectangle.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.UP) {
                if (!isStickExtended) {
                    // Pressed UP, start extending the stick
                    instructionLabel.setText("Stick is extending...");
                    extendStickTimeline.play();
                }
            }
        });

        // Add a key released event filter to handle UP key release
        stickRectangle.setOnKeyReleased(event -> {
            if (event.getCode() == KeyCode.UP && isStickExtended) {
                // Released UP after stick is extended, make the stick fall
                // Add logic for stick falling here, e.g., play a falling animation
                // You might want to use a separate Timeline for stick falling
                isStickExtended = false;
                extendStickTimeline.stop();
                // Reset the stick height
                stickRectangle.setHeight(0);
                instructionLabel.setText("Stick is falling...");
            }
        });
    }

    @FXML
    private void handleKeyPress(KeyEvent event) {
        if (event.getCode() == KeyCode.SPACE) {
            if (!isStickExtended) {
                // Pressed SPACE, start extending the stick
                instructionLabel.setText("Stick is extending...");
                extendStickTimeline.play();
            } else {
                // Pressed SPACE after stick is extended, make the stick fall
                instructionLabel.setText("Stick is falling...");
                // Add logic for stick falling here, e.g., play a falling animation
                // You might want to use a separate Timeline for stick falling
            }
        }
    }

    @FXML
    private void handleKeyRelease(KeyEvent event) {
        if (event.getCode() == KeyCode.SPACE && isStickExtended) {
            // Released SPACE after stick is extended, make the stick fall
            // Add logic for stick falling here, e.g., play a falling animation
            // You might want to use a separate Timeline for stick falling
        }
    }

//    private void checkStickLanding() {
//        //to check if the stick landed on another platform
//        // If it does, move the player to the new platform
//        // If not, handle the falling logic (e.g., game over)
//        rootPane.getChildren().remove(stick);
//    }

    private MainSceneController mainSceneController;
    public void setMainSceneController(MainSceneController mainSceneController) {
        this.mainSceneController = mainSceneController;
    }

    @FXML
    private void switchToMainScene() throws IOException {
        FXMLLoader mainLoader = new FXMLLoader(App.class.getResource("MainScene.fxml"));
        Scene mainScene = new Scene(mainLoader.load());
        MainSceneController mainController = mainLoader.getController();
        mainController.setHelpSceneController(this);
        Stage stage = (Stage) rootPane.getScene().getWindow();
        stage.setScene(mainScene);
    }
}
